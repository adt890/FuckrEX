coffee -cj fuckr.js services/*.coffee controllers/*.coffee fuckr.coffee
